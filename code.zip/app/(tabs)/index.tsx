import VarryPlatformView from "@/components/varry-platform-view";

export default function HomeScreen() {
  return <VarryPlatformView />;
}
