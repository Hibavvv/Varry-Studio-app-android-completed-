export const MAX_BRIDGE_FILE_BYTES = 64 * 1024 * 1024;
export const BRIDGE_CHUNK_CHARS = 256 * 1024;

export type VarryNativeMessage =
  | { type: "pick-file"; requestId: string; accept: string }
  | { type: "download-start"; downloadId: string; filename: string; mimeType: string; totalChars: number; chunkCount: number }
  | { type: "download-chunk"; downloadId: string; index: number; data: string }
  | { type: "download-end"; downloadId: string }
  | { type: "download-error"; message: string }
  | { type: "open-external"; url: string }
  | { type: "overlay-state"; open: boolean };

/** Runs only when the platform injects ReactNativeWebView; a normal browser keeps native file behavior. */
export const VARRY_WEBVIEW_BRIDGE = String.raw`(function () {
  if (!window.ReactNativeWebView || window.__varryNativeBridgeInstalled) return;
  window.__varryNativeBridgeInstalled = true;
  var pendingInputs = window.__varryPendingFileInputs = Object.create(null);
  var transfers = window.__varryNativeTransfers = Object.create(null);
  var objectUrls = Object.create(null);
  var lastOverlay = null;
  var sequence = 0;
  function send(message) {
    try { window.ReactNativeWebView.postMessage(JSON.stringify(message)); } catch (_) {}
  }
  function makeId(prefix) {
    sequence += 1;
    return prefix + '-' + Date.now() + '-' + sequence;
  }
  function sendBlob(blob, filename) {
    if (!blob || blob.size > 67108864) {
      send({ type: 'download-error', message: 'حجم الملف أكبر من الحد المدعوم في التطبيق (64 ميغابايت).' });
      return;
    }
    var reader = new FileReader();
    reader.onerror = function () { send({ type: 'download-error', message: 'تعذّر تجهيز الملف للتنزيل.' }); };
    reader.onload = async function () {
      var value = String(reader.result || '');
      var base64 = value.indexOf(',') >= 0 ? value.slice(value.indexOf(',') + 1) : value;
      var id = makeId('download');
      var count = Math.ceil(base64.length / 262144);
      send({ type: 'download-start', downloadId: id, filename: filename || 'Varry-Studio-export', mimeType: blob.type || 'application/octet-stream', totalChars: base64.length, chunkCount: count });
      for (var i = 0; i < count; i += 1) {
        send({ type: 'download-chunk', downloadId: id, index: i, data: base64.slice(i * 262144, (i + 1) * 262144) });
        await new Promise(function (resolve) { setTimeout(resolve, 0); });
      }
      send({ type: 'download-end', downloadId: id });
    };
    reader.readAsDataURL(blob);
  }
  window.__varryNativeBeginFile = function (metadata) {
    transfers[metadata.requestId] = { metadata: metadata, chunks: [] };
  };
  window.__varryNativeFileChunk = function (requestId, chunk) {
    if (transfers[requestId]) transfers[requestId].chunks.push(chunk);
  };
  window.__varryNativeEndFile = function (requestId) {
    var transfer = transfers[requestId];
    delete transfers[requestId];
    if (!transfer) return;
    var input = pendingInputs[requestId];
    delete pendingInputs[requestId];
    if (!input) return;
    try {
      var binary = atob(transfer.chunks.join(''));
      var bytes = new Uint8Array(binary.length);
      for (var i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
      var file = new File([bytes], transfer.metadata.name, { type: transfer.metadata.mimeType || 'application/octet-stream' });
      var data = new DataTransfer();
      data.items.add(file);
      input.files = data.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (error) {
      console.error('Varry native file bridge failed', error);
      send({ type: 'download-error', message: 'تعذّر فتح الملف المختار داخل المنصة.' });
    }
  };
  window.__varryNativeCancelFile = function (requestId) {
    delete pendingInputs[requestId];
    delete transfers[requestId];
  };
  var originalCreateObjectURL = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (object) {
    var url = originalCreateObjectURL(object);
    if (object instanceof Blob) objectUrls[url] = object;
    return url;
  };
  var originalRevokeObjectURL = URL.revokeObjectURL.bind(URL);
  URL.revokeObjectURL = function (url) {
    delete objectUrls[url];
    return originalRevokeObjectURL(url);
  };
  document.addEventListener('click', function (event) {
    var node = event.target;
    while (node && node !== document && !(node.matches && (node.matches('input[type="file"]') || node.matches('a[download]') || node.matches('a[target="_blank"]')))) node = node.parentElement;
    if (!node || node === document) return;
    if (node.matches('input[type="file"]')) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      var requestId = makeId('pick');
      pendingInputs[requestId] = node;
      send({ type: 'pick-file', requestId: requestId, accept: node.accept || '' });
      return;
    }
    if (node.matches('a[download]')) {
      var href = node.href || '';
      var blob = objectUrls[href];
      if (blob) {
        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
        sendBlob(blob, node.download || 'Varry-Studio-export');
        return;
      }
      if (href.indexOf('data:') === 0) {
        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
        fetch(href).then(function (response) { return response.blob(); }).then(function (data) { sendBlob(data, node.download || 'Varry-Studio-export'); }).catch(function () { send({ type: 'download-error', message: 'تعذّر تجهيز الصورة للتنزيل.' }); });
        return;
      }
    }
    if (node.matches('a[target="_blank"]')) {
      var externalUrl = node.href || '';
      if (/^(https?:|mailto:|tel:)/i.test(externalUrl)) {
        event.preventDefault();
        event.stopPropagation();
        send({ type: 'open-external', url: externalUrl });
      }
    }
  }, true);
  var originalWindowOpen = window.open;
  window.open = function (url) {
    if (/^(https?:|mailto:|tel:)/i.test(String(url || ''))) {
      send({ type: 'open-external', url: String(url) });
      return null;
    }
    return originalWindowOpen.apply(window, arguments);
  };
  function reportOverlay() {
    var open = !!document.querySelector('.modal.open') || !!(document.querySelector('#contextHelpPopover') && !document.querySelector('#contextHelpPopover').hidden) || !!document.querySelector('.export-dropdown.open, .new-dropdown.open, .style-palette-dropdown.open');
    if (open !== lastOverlay) {
      lastOverlay = open;
      send({ type: 'overlay-state', open: open });
    }
  }
  function attachObserver() {
    if (!document.documentElement) { setTimeout(attachObserver, 20); return; }
    new MutationObserver(reportOverlay).observe(document.documentElement, { subtree: true, attributes: true, attributeFilter: ['class', 'hidden', 'style'], childList: true });
    reportOverlay();
  }
  attachObserver();
})(); true;`;

export const VARRY_DISMISS_OVERLAY_SCRIPT = String.raw`(function () {
  var popover = document.querySelector('#contextHelpPopover');
  if (popover && !popover.hidden) {
    var helpClose = document.querySelector('#contextHelpClose');
    if (helpClose) helpClose.click();
    return true;
  }
  var modal = Array.prototype.slice.call(document.querySelectorAll('.modal.open')).pop();
  if (modal) {
    var close = modal.querySelector('.modal-x');
    if (close) close.click();
    else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    return true;
  }
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  return true;
})(); true;`;

export function acceptsPickedFile(accept: string, filename: string, mimeType = ""): boolean {
  const normalizedAccept = accept.toLowerCase();
  const extension = filename.toLowerCase().split(".").pop() ?? "";
  if (!normalizedAccept || normalizedAccept.includes("*/*")) return true;
  if (normalizedAccept.includes(".html") || normalizedAccept.includes(".htm") || normalizedAccept.includes("text/html")) {
    return extension === "html" || extension === "htm";
  }
  if (normalizedAccept.includes(".json") || normalizedAccept.includes("application/json")) return extension === "json";
  if (normalizedAccept.includes("image/")) return mimeType.startsWith("image/") || ["png", "jpg", "jpeg", "webp", "gif", "svg"].includes(extension);
  return normalizedAccept.split(",").some((item) => item.trim().startsWith(".") && item.trim().slice(1) === extension);
}

export function safeExportFilename(filename: string): string {
  const cleaned = filename.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "-").replace(/\s+/g, " ").trim().slice(0, 140);
  return cleaned || "Varry-Studio-export";
}
