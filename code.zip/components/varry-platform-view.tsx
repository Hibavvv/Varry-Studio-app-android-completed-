export { default } from "./varry-platform-view.native";
