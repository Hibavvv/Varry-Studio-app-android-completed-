import { createElement } from "react";
import { View } from "react-native";

export default function VarryPlatformView() {
  return (
    <View style={{ flex: 1, backgroundColor: "#efe8d8" }}>
      {createElement("iframe", {
        title: "Varry Studio",
        src: "/varry-studio.html",
        style: { display: "block", width: "100%", height: "100%", border: 0, backgroundColor: "#efe8d8" },
        allow: "clipboard-read; clipboard-write",
      })}
    </View>
  );
}
