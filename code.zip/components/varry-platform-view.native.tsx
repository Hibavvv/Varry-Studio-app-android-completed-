import { Asset } from "expo-asset";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, BackHandler, Linking, StatusBar, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import WebView, { type WebViewMessageEvent, type WebViewNavigation } from "react-native-webview";
import {
  acceptsPickedFile,
  BRIDGE_CHUNK_CHARS,
  MAX_BRIDGE_FILE_BYTES,
  safeExportFilename,
  VARRY_DISMISS_OVERLAY_SCRIPT,
  VARRY_WEBVIEW_BRIDGE,
  type VarryNativeMessage,
} from "@/lib/varry-native-bridge";

const APP_ORIGIN = "https://varry-studio.local/";
const HTML_ASSET = require("../assets/varry-studio.html");

type PendingDownload = {
  filename: string;
  mimeType: string;
  totalChars: number;
  chunkCount: number;
  chunks: string[];
};

type PickRequest = Extract<VarryNativeMessage, { type: "pick-file" }>;

function asMessage(value: string): VarryNativeMessage | null {
  try {
    const parsed = JSON.parse(value) as VarryNativeMessage;
    return parsed && typeof parsed.type === "string" ? parsed : null;
  } catch {
    return null;
  }
}

export default function VarryPlatformView() {
  const webViewRef = useRef<WebView>(null);
  const pendingDownloads = useRef(new Map<string, PendingDownload>());
  const modalOpen = useRef(false);
  const canGoBack = useRef(false);
  const [html, setHtml] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [pageLoaded, setPageLoaded] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const localNoticeShown = useRef(false);

  const showLocalStorageNotice = useCallback(async () => {
    if (localNoticeShown.current) return;
    localNoticeShown.current = true;
    const noticeUri = FileSystem.documentDirectory ? `${FileSystem.documentDirectory}varry-local-storage-notice-v1` : null;
    if (noticeUri) {
      try {
        const previousNotice = await FileSystem.getInfoAsync(noticeUri);
        if (previousNotice.exists) return;
      } catch (error) {
        console.warn("Could not check local storage notice state", error);
      }
    }
    Alert.alert(
      "حفظ الأعمال على هذا الجهاز",
      "تُحفظ الأعمال محلياً في مساحة التطبيق، وهي منفصلة عن بيانات المتصفح ولا تنتقل تلقائياً إلى هاتف آخر. استخدم النسخ الاحتياطية لنقل الأعمال أو استعادتها.",
      [{
        text: "موافق",
        onPress: () => {
          if (noticeUri) void FileSystem.writeAsStringAsync(noticeUri, "acknowledged").catch((error) => console.warn("Could not save local notice state", error));
        },
      }],
      { cancelable: false },
    );
  }, []);

  useEffect(() => {
    void showLocalStorageNotice();
  }, [showLocalStorageNotice]);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const asset = Asset.fromModule(HTML_ASSET);
        await asset.downloadAsync();
        const uri = asset.localUri ?? asset.uri;
        const source = await FileSystem.readAsStringAsync(uri);
        if (active) setHtml(source);
      } catch (error) {
        console.error("Unable to load bundled Varry Studio HTML", error);
        if (active) setLoadError("تعذّر فتح ملفات المنصة المضمّنة. أعد تشغيل التطبيق وحاول مجدداً.");
      }
    })();
    return () => { active = false; };
  }, [reloadKey]);

  const inject = useCallback((script: string) => {
    webViewRef.current?.injectJavaScript(`${script}\ntrue;`);
  }, []);

  const sendPickedFileToPage = useCallback(async (request: PickRequest) => {
    try {
      const selection = await DocumentPicker.getDocumentAsync({
        type: "*/*",
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (selection.canceled || !selection.assets?.[0]) {
        inject(`window.__varryNativeCancelFile && window.__varryNativeCancelFile(${JSON.stringify(request.requestId)});`);
        return;
      }
      const selected = selection.assets[0];
      if (!acceptsPickedFile(request.accept, selected.name, selected.mimeType ?? "")) {
        Alert.alert("نوع ملف غير مدعوم", "اختر ملفاً من النوع المسموح به في هذه العملية.");
        inject(`window.__varryNativeCancelFile && window.__varryNativeCancelFile(${JSON.stringify(request.requestId)});`);
        return;
      }
      const details = await FileSystem.getInfoAsync(selected.uri);
      const fileSize = selected.size ?? (details.exists ? details.size : undefined) ?? 0;
      if (fileSize > MAX_BRIDGE_FILE_BYTES) {
        Alert.alert("الملف كبير جداً", "حجم الملف الأقصى المدعوم حالياً 64 ميغابايت.");
        inject(`window.__varryNativeCancelFile && window.__varryNativeCancelFile(${JSON.stringify(request.requestId)});`);
        return;
      }
      const base64 = await FileSystem.readAsStringAsync(selected.uri, { encoding: FileSystem.EncodingType.Base64 });
      const chunks = Math.ceil(base64.length / BRIDGE_CHUNK_CHARS);
      const metadata = {
        requestId: request.requestId,
        name: selected.name,
        mimeType: selected.mimeType ?? "application/octet-stream",
        chunkCount: chunks,
      };
      inject(`window.__varryNativeBeginFile && window.__varryNativeBeginFile(${JSON.stringify(metadata)});`);
      for (let index = 0; index < chunks; index += 1) {
        const part = base64.slice(index * BRIDGE_CHUNK_CHARS, (index + 1) * BRIDGE_CHUNK_CHARS);
        inject(`window.__varryNativeFileChunk && window.__varryNativeFileChunk(${JSON.stringify(request.requestId)},${JSON.stringify(part)});`);
        await new Promise<void>((resolve) => setTimeout(resolve, 0));
      }
      inject(`window.__varryNativeEndFile && window.__varryNativeEndFile(${JSON.stringify(request.requestId)});`);
    } catch (error) {
      console.error("Native file picker failed", error);
      inject(`window.__varryNativeCancelFile && window.__varryNativeCancelFile(${JSON.stringify(request.requestId)});`);
      Alert.alert("تعذّر فتح الملف", "لم يتمكن التطبيق من قراءة الملف المختار.");
    }
  }, [inject]);

  const finishDownload = useCallback(async (downloadId: string) => {
    const download = pendingDownloads.current.get(downloadId);
    pendingDownloads.current.delete(downloadId);
    if (!download) return;
    const base64 = download.chunks.join("");
    if (base64.length !== download.totalChars || download.chunks.length !== download.chunkCount) {
      Alert.alert("تعذّر تجهيز الملف", "لم تكتمل بيانات الملف المُصدّر؛ حاول التصدير مجدداً.");
      return;
    }
    if (base64.length > MAX_BRIDGE_FILE_BYTES * 1.4) {
      Alert.alert("الملف كبير جداً", "حجم الملف الأقصى المدعوم حالياً 64 ميغابايت.");
      return;
    }
    const root = FileSystem.cacheDirectory ?? FileSystem.documentDirectory;
    if (!root) {
      Alert.alert("تعذّر حفظ الملف", "مساحة الملفات المؤقتة غير متاحة على هذا الجهاز.");
      return;
    }
    try {
      const filename = safeExportFilename(download.filename);
      const uri = `${root}${Date.now()}-${filename}`;
      await FileSystem.writeAsStringAsync(uri, base64, { encoding: FileSystem.EncodingType.Base64 });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: download.mimeType, dialogTitle: `مشاركة ${filename}` });
      } else {
        Alert.alert("تم تجهيز الملف", `حُفظ الملف مؤقتاً باسم ${filename}، لكن المشاركة غير متاحة على هذا الجهاز.`);
      }
    } catch (error) {
      console.error("Native export failed", error);
      Alert.alert("تعذّر حفظ الملف", "أعد محاولة التصدير أو تأكد من توفر مساحة على الهاتف.");
    }
  }, []);

  const handleMessage = useCallback((event: WebViewMessageEvent) => {
    const message = asMessage(event.nativeEvent.data);
    if (!message) return;
    if (message.type === "pick-file") {
      void sendPickedFileToPage(message);
      return;
    }
    if (message.type === "download-start") {
      if (message.totalChars > MAX_BRIDGE_FILE_BYTES * 1.4 || message.chunkCount > 400) {
        Alert.alert("الملف كبير جداً", "حجم الملف الأقصى المدعوم حالياً 64 ميغابايت.");
        pendingDownloads.current.delete(message.downloadId);
        return;
      }
      pendingDownloads.current.set(message.downloadId, {
        filename: message.filename,
        mimeType: message.mimeType,
        totalChars: message.totalChars,
        chunkCount: message.chunkCount,
        chunks: [],
      });
      return;
    }
    if (message.type === "download-chunk") {
      const transfer = pendingDownloads.current.get(message.downloadId);
      if (transfer) transfer.chunks[message.index] = message.data;
      return;
    }
    if (message.type === "download-end") {
      void finishDownload(message.downloadId);
      return;
    }
    if (message.type === "download-error") {
      Alert.alert("التنزيل", message.message);
      return;
    }
    if (message.type === "open-external") {
      if (/^(https?:|mailto:|tel:)/i.test(message.url)) void Linking.openURL(message.url).catch(() => Alert.alert("تعذّر فتح الرابط", message.url));
      return;
    }
    if (message.type === "overlay-state") modalOpen.current = message.open;
  }, [finishDownload, sendPickedFileToPage]);

  const handleNavigationChange = useCallback((navigation: WebViewNavigation) => {
    canGoBack.current = navigation.canGoBack;
  }, []);

  const shouldStartNavigation = useCallback((request: { url: string; isTopFrame?: boolean }) => {
    if (request.url.startsWith(APP_ORIGIN) || request.url === "about:blank" || request.url.startsWith("data:") || request.url.startsWith("blob:")) return true;
    if (/^(https?:|mailto:|tel:)/i.test(request.url)) {
      void Linking.openURL(request.url).catch(() => Alert.alert("تعذّر فتح الرابط", "تأكد من وجود تطبيق مناسب أو اتصال إنترنت."));
    }
    return false;
  }, []);

  useEffect(() => {
    const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
      if (modalOpen.current) {
        inject(VARRY_DISMISS_OVERLAY_SCRIPT);
        return true;
      }
      if (canGoBack.current) {
        webViewRef.current?.goBack();
        return true;
      }
      return false;
    });
    return () => subscription.remove();
  }, [inject]);

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "bottom"]}>
      <StatusBar barStyle="dark-content" backgroundColor="#f5f2ea" />
      {html && !loadError ? (
        <WebView
          ref={webViewRef}
          key={reloadKey}
          style={styles.webView}
          source={{ html, baseUrl: APP_ORIGIN }}
          originWhitelist={["*"]}
          javaScriptEnabled
          domStorageEnabled
          cacheEnabled
          allowFileAccess={false}
          allowUniversalAccessFromFileURLs={false}
          mixedContentMode="never"
          javaScriptCanOpenWindowsAutomatically={false}
          setSupportMultipleWindows={false}
          sharedCookiesEnabled={false}
          injectedJavaScriptBeforeContentLoaded={VARRY_WEBVIEW_BRIDGE}
          injectedJavaScript={VARRY_WEBVIEW_BRIDGE}
          onMessage={handleMessage}
          onNavigationStateChange={handleNavigationChange}
          onShouldStartLoadWithRequest={shouldStartNavigation}
          onLoadEnd={() => setPageLoaded(true)}
          onError={(event) => {
            setLoadError(event.nativeEvent.description || "تعذّر تحميل المنصة.");
          }}
          setBuiltInZoomControls={false}
          setDisplayZoomControls={false}
          textZoom={100}
          allowsBackForwardNavigationGestures
        />
      ) : null}
      {!html && !loadError ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color="#7a3b2e" />
          <Text style={styles.statusText}>جارٍ تجهيز Varry Studio…</Text>
        </View>
      ) : null}
      {loadError ? (
        <View style={styles.loading}>
          <Text style={styles.errorTitle}>تعذّر فتح المنصة</Text>
          <Text style={styles.statusText}>{loadError}</Text>
          <Text accessibilityRole="button" onPress={() => { setLoadError(null); setHtml(null); setPageLoaded(false); setReloadKey((key) => key + 1); }} style={styles.retry}>إعادة المحاولة</Text>
        </View>
      ) : null}
      {html && !pageLoaded && !loadError ? (
        <View pointerEvents="none" style={styles.loadingOverlay}>
          <ActivityIndicator size="small" color="#7a3b2e" />
        </View>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#f7f3ea" },
  webView: { flex: 1, backgroundColor: "#efe8d8" },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24, gap: 16, backgroundColor: "#f7f3ea" },
  loadingOverlay: { position: "absolute", top: 14, alignSelf: "center", borderRadius: 18, padding: 8, backgroundColor: "rgba(247,243,234,0.92)" },
  statusText: { color: "#51473e", fontSize: 15, textAlign: "center", writingDirection: "rtl", lineHeight: 24 },
  errorTitle: { color: "#7a3b2e", fontSize: 19, fontWeight: "700", textAlign: "center", writingDirection: "rtl" },
  retry: { color: "#fffaf2", backgroundColor: "#7a3b2e", borderRadius: 10, paddingVertical: 11, paddingHorizontal: 22, overflow: "hidden", fontSize: 14, fontWeight: "700", writingDirection: "rtl" },
});
